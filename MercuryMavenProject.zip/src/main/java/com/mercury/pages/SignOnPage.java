package com.mercury.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.mercury.testbase.TestBase;

public class SignOnPage extends TestBase {

	WebElement welcomeText;


	public SignOnPage() {

		
		welcomeText = driver.findElement(By.xpath("//*[contains(text(),'Welcome back to')]"));
	}
	
	public String verifyPageTitle(){
		return driver.getTitle();
	}
	
	public boolean verifyWelcomeText(){
		return welcomeText.isDisplayed();
	}
	
	

}

	