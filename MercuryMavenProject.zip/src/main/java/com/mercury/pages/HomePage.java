package com.mercury.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.mercury.testbase.TestBase;

public class HomePage extends TestBase {

	//Declaring the variables- page objects
	WebElement username;
	WebElement password;
	WebElement loginButton;	

	public HomePage() {
		//Initializing the page objects
		username = driver.findElement(By.name("userName"));
		password = driver.findElement(By.name("password"));
		loginButton = driver.findElement(By.name("login"));
	}
	
	public String verifyHomePageTitle(){
		return driver.getTitle();
	}
	

	
	public SignOnPage login(String strUsername, String strPassword) {
		username.sendKeys(strUsername);
		password.sendKeys(strPassword);
		loginButton.click();
		return new SignOnPage();
	}
	

}
